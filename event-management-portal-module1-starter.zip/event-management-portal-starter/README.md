# Event Management Portal

Starter structure for a Java Full Stack Event Management Portal.

## Stack
- React (Vite)
- Spring Boot
- MySQL
- JWT Authentication

This starter was generated as Module 1.
